
#ifndef H_SMIMS_DEFINE
#define H_SMIMS_DEFINE

typedef struct libusb_device_handle * USB_HANDLE;

#endif
